
import React from 'react';

export const Footer = ({ couple }) => {
  return (
    <footer className="py-12 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-gray-600">
        <h3 
          className="text-4xl font-bold mb-4"
          style={{ fontFamily: "'Great Vibes', cursive" }}
        >
          {couple.bride} & {couple.groom}
        </h3>
        <p className="text-lg mb-2">Thank you for being a part of our special day!</p>
        <p className="text-pink-500 text-2xl mb-4">&hearts;</p>
        <p>&copy; {new Date().getFullYear()} {couple.bride} & {couple.groom}. All Rights Reserved.</p>
      </div>
    </footer>
  );
};
