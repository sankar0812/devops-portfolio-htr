
import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';

export const HeroSection = ({ couple, scrollToSection, HeartIcon }) => {
  return (
    <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden bg-cover bg-center" style={{ backgroundImage: "url('https://images.unsplash.com/photo-1522083165195-3424ed129620?q=80&w=2070')" }}>
      <div className="absolute inset-0 bg-black/30" />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10 text-white">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
        >
          <motion.h2 
            className="text-2xl md:text-3xl mb-4 tracking-widest"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 0.5 }}
          >
            WE ARE GETTING MARRIED
          </motion.h2>
          
          <motion.h1 
            className="text-6xl md:text-8xl font-bold mb-4"
            style={{ fontFamily: "'Playfair Display', serif" }}
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.8 }}
          >
            {couple.bride} & {couple.groom}
          </motion.h1>

          <motion.p 
            className="text-2xl md:text-3xl mb-8"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 1.2 }}
          >
            {couple.date}
          </motion.p>
          
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 1.5 }}
          >
            <Button 
              size="lg" 
              className="gradient-bg text-white hover:scale-105 transition-transform duration-300 pulse-glow"
              onClick={() => scrollToSection('rsvp')}
            >
              <HeartIcon className="mr-2 h-5 w-5" />
              RSVP Now
            </Button>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};
