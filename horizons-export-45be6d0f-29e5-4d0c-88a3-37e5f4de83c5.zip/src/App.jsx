
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Toaster } from '@/components/ui/toaster';
import { toast } from '@/components/ui/use-toast';
import { Navbar } from '@/components/Navbar';
import { HeroSection } from '@/components/HeroSection';
import { OurStorySection } from '@/components/OurStorySection';
import { EventTimelineSection } from '@/components/EventTimelineSection';
import { GallerySection } from '@/components/GallerySection';
import { RsvpSection } from '@/components/RsvpSection';
import { Footer } from '@/components/Footer';
import { 
  Heart, 
  Calendar, 
  MapPin, 
  Camera, 
  Gift, 
  Menu, 
  X,
  Send
} from 'lucide-react';

const App = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    document.documentElement.classList.add('scroll-smooth');
    document.body.style.backgroundColor = '#FFF9FB';
  }, []);

  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMenuOpen(false);
  };

  const handleRsvpSubmit = (data) => {
    console.log("RSVP Data:", data);
    localStorage.setItem(`rsvp_${data.name}`, JSON.stringify(data));
    toast({
      title: "💖 Thank You!",
      description: "Your RSVP has been received. We can't wait to celebrate with you!",
    });
  };

  const navItems = ['Home', 'Our Story', 'Events', 'Gallery', 'RSVP'];

  const couple = {
    groom: "John Doe",
    bride: "Jane Smith",
    date: "October 26, 2025",
  };

  const storyData = {
    title: "Our Story",
    subtitle: "Two hearts, one journey.",
    story: "From a chance encounter to a lifetime of love, our journey has been nothing short of magical. We met on a sunny afternoon, and from that moment, we knew we had found something special. We've shared countless laughs, supported each other through challenges, and built a love that we'll cherish forever. We are so excited to start our next chapter as husband and wife and to share this joyous occasion with you.",
    groomImage: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2",
    brideImage: "https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e",
  };

  const eventsData = {
    title: "Wedding Events",
    subtitle: "Join us as we celebrate our love.",
    events: [
      {
        icon: Heart,
        title: "The Ceremony",
        time: "2:00 PM",
        location: "St. Paul's Cathedral, London",
        description: "Witness our vows in a beautiful and historic setting.",
      },
      {
        icon: Camera,
        title: "Cocktail Hour",
        time: "4:00 PM",
        location: "The Garden Terrace",
        description: "Mingle and enjoy drinks and appetizers.",
      },
      {
        icon: Gift,
        title: "The Reception",
        time: "6:00 PM",
        location: "The Grand Ballroom, The Savoy",
        description: "Dine, dance, and celebrate with us through the night.",
      },
    ],
  };

  const galleryData = {
    title: "Our Moments",
    subtitle: "A glimpse into our journey.",
    images: [
      { src: "https://images.unsplash.com/photo-1523438943993-12acea9b35a7", alt: "Couple laughing together" },
      { src: "https://images.unsplash.com/photo-1515934751635-481c60802202", alt: "Couple on a beach at sunset" },
      { src: "https://images.unsplash.com/photo-1546193430-c2d209534518", alt: "Couple holding hands" },
      { src: "https://images.unsplash.com/photo-1551022372-3bd33b584d8a", alt: "Proposal moment" },
      { src: "https://images.unsplash.com/photo-1529946179074-97a1b6152298", alt: "Couple hiking in the mountains" },
      { src: "https://images.unsplash.com/photo-1532328233499-eac1b9b55acb", alt: "Couple enjoying a coffee date" },
    ],
  };

  return (
    <div className="min-h-screen bg-[#FFF9FB] text-gray-800 overflow-x-hidden">
      <Toaster />
      <Navbar 
        navItems={navItems} 
        isMenuOpen={isMenuOpen} 
        setIsMenuOpen={setIsMenuOpen} 
        scrollToSection={scrollToSection}
        MenuIcon={Menu}
        XIcon={X}
      />
      <HeroSection couple={couple} scrollToSection={scrollToSection} HeartIcon={Heart} />
      <OurStorySection data={storyData} />
      <EventTimelineSection data={eventsData} CalendarIcon={Calendar} MapPinIcon={MapPin} />
      <GallerySection data={galleryData} />
      <RsvpSection onSubmit={handleRsvpSubmit} SendIcon={Send} />
      <Footer couple={couple} />
    </div>
  );
};

export default App;
