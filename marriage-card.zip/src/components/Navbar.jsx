import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';

export const Navbar = ({ navItems, isMenuOpen, setIsMenuOpen, scrollToSection, MenuIcon, XIcon }) => {
  return (
    <motion.nav 
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      className="fixed top-0 w-full z-50 glass-effect shadow-md"
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <motion.div 
            whileHover={{ scale: 1.05, rotate: -2 }}
            className="text-3xl font-bold"
            style={{ fontFamily: "'Great Vibes', cursive" }}
          >
            <a href="#home" onClick={(e) => {e.preventDefault(); scrollToSection('home');}} className="text-pink-600 hover:text-pink-700 transition-colors">
              {/* Using initials as a common practice */}
              J <span className="text-gray-600">&</span> J
            </a>
          </motion.div>
          
          <div className="hidden md:flex space-x-8 items-center">
            {navItems.map((item) => (
              <motion.button
                key={item}
                whileHover={{ scale: 1.1, color: '#db2777' }} /* Deeper pink for hover */
                whileTap={{ scale: 0.95 }}
                onClick={() => scrollToSection(item.toLowerCase().replace(' ', ''))}
                className="text-gray-700 hover:text-pink-600 transition-colors duration-300 text-lg font-medium"
                style={{ fontFamily: "'Montserrat', sans-serif" }}
              >
                {item}
              </motion.button>
            ))}
          </div>

          <div className="md:hidden">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-gray-700 hover:text-pink-600"
            >
              {isMenuOpen ? <XIcon className="h-7 w-7" /> : <MenuIcon className="h-7 w-7" />}
            </Button>
          </div>
        </div>
      </div>

      {isMenuOpen && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          transition={{ duration: 0.3, ease: "easeInOut" }}
          className="md:hidden glass-effect border-t border-pink-100"
        >
          <div className="px-6 py-4 space-y-3">
            {navItems.map((item) => (
              <button
                key={item}
                onClick={() => scrollToSection(item.toLowerCase().replace(' ', ''))}
                className="block w-full text-left text-gray-700 hover:text-pink-600 transition-colors duration-300 text-lg py-2"
                style={{ fontFamily: "'Montserrat', sans-serif" }}
              >
                {item}
              </button>
            ))}
          </div>
        </motion.div>
      )}
    </motion.nav>
  );
};