
import React from 'react';
import { motion } from 'framer-motion';

export const OurStorySection = ({ data }) => {
  const { title, subtitle, story, groomImage, brideImage } = data;
  return (
    <section id="ourstory" className="py-24 bg-white">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl md:text-6xl font-bold mb-4 gradient-text">{title}</h2>
          <p className="text-xl text-gray-500">{subtitle}</p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
            className="flex justify-center"
          >
            <img 
              className="rounded-full shadow-xl w-48 h-48 md:w-56 md:h-56 object-cover border-4 border-white"
              alt="Photo of the groom"
             src="https://images.unsplash.com/photo-1548302337-8e7b558b7d6f" />
          </motion.div>

          <motion.p
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            viewport={{ once: true }}
            className="text-lg text-gray-600 leading-relaxed text-center md:col-span-1"
          >
            {story}
          </motion.p>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
            className="flex justify-center"
          >
            <img 
              className="rounded-full shadow-xl w-48 h-48 md:w-56 md:h-56 object-cover border-4 border-white"
              alt="Photo of the bride"
             src="https://images.unsplash.com/photo-1549670526-6804c8b968bd" />
          </motion.div>
        </div>
      </div>
    </section>
  );
};
