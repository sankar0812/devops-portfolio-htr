
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight, X, Maximize } from 'lucide-react';

export const GallerySection = ({ data }) => {
  const { title, subtitle, images } = data;
  const [selectedImage, setSelectedImage] = useState(null);
  const [currentIndex, setCurrentIndex] = useState(0);

  const openLightbox = (index) => {
    setCurrentIndex(index);
    setSelectedImage(images[index]);
  };

  const closeLightbox = () => {
    setSelectedImage(null);
  };

  const goToPrevious = (e) => {
    e.stopPropagation();
    const newIndex = (currentIndex - 1 + images.length) % images.length;
    setCurrentIndex(newIndex);
    setSelectedImage(images[newIndex]);
  };

  const goToNext = (e) => {
    e.stopPropagation();
    const newIndex = (currentIndex + 1) % images.length;
    setCurrentIndex(newIndex);
    setSelectedImage(images[newIndex]);
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  };

  const imageVariants = {
    hidden: { opacity: 0, y: 50, scale: 0.9 },
    visible: {
      opacity: 1,
      y: 0,
      scale: 1,
      transition: {
        type: 'spring',
        stiffness: 100,
        damping: 12,
        duration: 0.5,
      },
    },
    hover: {
      scale: 1.03,
      boxShadow: "0px 20px 40px rgba(217, 119, 6, 0.25)",
      transition: { duration: 0.3, ease: "circOut" },
    },
  };
  
  const lightboxVariants = {
    initial: { opacity: 0, scale: 0.9, backdropFilter: "blur(0px)" },
    animate: { opacity: 1, scale: 1, backdropFilter: "blur(10px) saturate(150%)", transition: { duration: 0.4, ease: [0.4, 0, 0.2, 1] } },
    exit: { opacity: 0, scale: 0.9, backdropFilter: "blur(0px)", transition: { duration: 0.3, ease: [0.4, 0, 0.2, 1] } }
  };

  const lightboxImageVariants = {
    initial: { opacity: 0, y: 20, scale: 0.95 },
    animate: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.4, ease: [0.4, 0, 0.2, 1], delay: 0.1 } },
    exit: { opacity: 0, y: -20, scale: 0.95, transition: { duration: 0.3 } }
  };

  return (
    <section id="gallery" className="py-20 md:py-28 bg-gradient-to-br from-[#FFFDF9] to-[#FFF0E0]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: -30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: "easeOut" }}
          viewport={{ once: true }}
          className="text-center mb-16 md:mb-20"
        >
          <h2 className="text-5xl md:text-6xl font-bold mb-4 gradient-text tracking-tight">{title}</h2>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto leading-relaxed" style={{ fontFamily: "'Lora', serif" }}>{subtitle}</p>
        </motion.div>

        <motion.div 
          className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5 md:gap-8"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.1 }}
        >
          {images.map((image, index) => (
            <motion.div
              key={image.id}
              variants={imageVariants}
              whileHover="hover"
              className="group relative aspect-w-3 aspect-h-4 overflow-hidden rounded-xl shadow-xl cursor-pointer border-2 border-transparent hover:border-amber-500 transition-colors duration-300"
              onClick={() => openLightbox(index)}
              layoutId={`gallery-image-${image.id}`}
            >
              <div className="absolute inset-0 overflow-hidden">
                 <img-replace 
                  className="w-full h-full object-cover transition-transform duration-700 ease-in-out group-hover:scale-110"
                  alt={image.altText} />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-400 ease-in-out flex flex-col justify-end p-4 md:p-5">
                <p className="text-white text-sm md:text-base font-semibold drop-shadow-lg leading-tight" style={{ fontFamily: "'Lora', serif" }}>{image.altText}</p>
                <Maximize className="w-5 h-5 md:w-6 md:h-6 text-white/60 absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300 transform group-hover:scale-110" />
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>

      <AnimatePresence>
        {selectedImage && (
          <motion.div
            variants={lightboxVariants}
            initial="initial"
            animate="animate"
            exit="exit"
            className="fixed inset-0 bg-black/80 z-[100] flex items-center justify-center p-3 md:p-4"
            onClick={closeLightbox}
          >
            <motion.div 
              className="relative w-full max-w-xl md:max-w-3xl lg:max-w-4xl max-h-[90vh] bg-white rounded-xl shadow-2xl overflow-hidden flex flex-col"
              onClick={(e) => e.stopPropagation()}
              layoutId={`gallery-image-${selectedImage.id}`}
              variants={lightboxImageVariants}
            >
              <div className="w-full h-auto max-h-[calc(90vh-80px)] overflow-hidden flex-grow flex items-center justify-center bg-gray-100">
                <img-replace 
                  className="max-w-full max-h-full object-contain"
                  alt={selectedImage.altText} />
              </div>
              <div className="p-4 md:p-5 text-center text-gray-800 bg-amber-50 border-t-2 border-amber-200">
                <p className="text-base md:text-lg" style={{ fontFamily: "'Lora', serif" }}>{selectedImage.altText}</p>
              </div>
              
              <button
                onClick={closeLightbox}
                className="absolute top-3 right-3 text-gray-700 bg-white/70 hover:bg-white/90 backdrop-blur-sm rounded-full p-2.5 transition-all duration-200 z-10 shadow-md"
                aria-label="Close lightbox"
              >
                <X size={22} />
              </button>
            </motion.div>
            
            <motion.button
                onClick={goToPrevious}
                initial={{ opacity: 0, x: -20 }} animate={{ opacity:1, x: 0 }} exit={{ opacity:0, x: -20 }}
                transition={{ duration: 0.3, delay: 0.2 }}
                className="absolute left-2 md:left-5 top-1/2 -translate-y-1/2 text-white bg-black/50 hover:bg-black/70 backdrop-blur-sm rounded-full p-3 transition-all duration-200 z-10 shadow-lg"
                aria-label="Previous image"
            >
                <ChevronLeft size={28} />
            </motion.button>
            
            <motion.button
              onClick={goToNext}
              initial={{ opacity: 0, x: 20 }} animate={{ opacity:1, x: 0 }} exit={{ opacity:0, x: 20 }}
              transition={{ duration: 0.3, delay: 0.2 }}
              className="absolute right-2 md:right-5 top-1/2 -translate-y-1/2 text-white bg-black/50 hover:bg-black/70 backdrop-blur-sm rounded-full p-3 transition-all duration-200 z-10 shadow-lg"
              aria-label="Next image"
            >
              <ChevronRight size={28} />
            </motion.button>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
};
