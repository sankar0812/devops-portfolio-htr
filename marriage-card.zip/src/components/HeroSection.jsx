import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';

export const HeroSection = ({ couple, scrollToSection, HeartIcon, GiftIcon, onRegistryClick }) => {
  return (
    <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden bg-cover bg-center" style={{ backgroundImage: "url('https://images.unsplash.com/photo-1522083165195-3424ed129620?q=80&w=2070')" }}>
      <div className="absolute inset-0 bg-black/40" />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10 text-white">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
        >
          <motion.h2 
            className="text-2xl md:text-3xl mb-4 tracking-widest uppercase"
            style={{ fontFamily: "'Montserrat', sans-serif" }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 0.5 }}
          >
            We are getting married
          </motion.h2>
          
          <motion.h1 
            className="text-6xl md:text-8xl font-bold mb-4"
            style={{ fontFamily: "'Playfair Display', serif" }}
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.8, type: "spring", stiffness: 100 }}
          >
            {couple.bride} <span className="text-pink-300">&</span> {couple.groom}
          </motion.h1>

          <motion.p 
            className="text-2xl md:text-3xl mb-8"
            style={{ fontFamily: "'Crimson Text', serif" }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 1.2 }}
          >
            {couple.date}
          </motion.p>
          
          <motion.div 
            className="flex flex-col sm:flex-row justify-center items-center space-y-4 sm:space-y-0 sm:space-x-6"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 1.5 }}
          >
            <Button 
              size="lg" 
              className="gradient-bg text-white hover:scale-105 transition-transform duration-300 pulse-glow shadow-lg px-8 py-3 text-lg"
              onClick={() => scrollToSection('events')}
            >
              <HeartIcon className="mr-2 h-5 w-5" />
              Event Details
            </Button>
            <Button 
              size="lg" 
              variant="outline"
              className="text-white border-white hover:bg-white hover:text-pink-500 transition-colors duration-300 shadow-lg px-8 py-3 text-lg backdrop-blur-sm bg-white/10"
              onClick={onRegistryClick}
            >
              <GiftIcon className="mr-2 h-5 w-5" />
              Gift Registry
            </Button>
          </motion.div>
        </motion.div>
      </div>
       <motion.div
        className="absolute bottom-10 left-1/2 -translate-x-1/2"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 2, repeat: Infinity, repeatType: "reverse", ease: "easeInOut" }}
       >
        <HeartIcon className="w-8 h-8 text-pink-300 animate-pulse" />
      </motion.div>
    </section>
  );
};