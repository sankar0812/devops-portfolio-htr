import React, { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

const iconRetinaUrl = 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png';
const iconUrl = 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png';
const shadowUrl = 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png';

const DefaultIcon = L.icon({
  iconRetinaUrl,
  iconUrl,
  shadowUrl,
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  tooltipAnchor: [16, -28],
  shadowSize: [41, 41],
});

L.Marker.prototype.options.icon = DefaultIcon;

const ChangeView = ({ center, zoom }) => {
  const map = useMap();
  useEffect(() => {
    if (center && map) {
      map.setView(center, zoom);
      map.eachLayer((layer) => {
        if (layer instanceof L.Marker && layer.getLatLng().equals(L.latLng(center))) {
          if (layer.getPopup()) {
             layer.openPopup();
          }
        }
      });
    }
  }, [center, zoom, map]);
  return null;
};


export const LocationSection = ({ data, NavigationIcon }) => {
  const { title, subtitle, mainLocation, additionalLocations } = data;
  const [currentCenter, setCurrentCenter] = useState(mainLocation.coordinates);
  const [currentZoom, setCurrentZoom] = useState(mainLocation.zoom);
  const [activeLocationName, setActiveLocationName] = useState(mainLocation.name);
  const mapRef = useRef(null);
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  useEffect(() => {
    const handleMapFocus = (event) => {
      const { coordinates, name } = event.detail;
      if (coordinates && name) {
        setCurrentCenter(coordinates);
        setCurrentZoom(16); 
        setActiveLocationName(name);
      }
    };

    window.addEventListener('mapFocus', handleMapFocus);
    return () => {
      window.removeEventListener('mapFocus', handleMapFocus);
    };
  }, []);
  

  const handleLocationSelect = (location) => {
    setCurrentCenter(location.coordinates);
    setCurrentZoom(16);
    setActiveLocationName(location.name);
     if (mapRef.current) {
      mapRef.current.flyTo(location.coordinates, 16);
    }
  };

  if (!isClient) {
    return <div className="min-h-[450px] flex items-center justify-center"><p>Loading map...</p></div>;
  }

  return (
    <section id="location" className="py-24 bg-[#FFF9FB]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl md:text-6xl font-bold mb-4 gradient-text">{title}</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">{subtitle}</p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          <motion.div 
            className="md:col-span-1 space-y-6"
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <h3 className="text-3xl font-semibold text-pink-600 mb-4" style={{ fontFamily: "'Playfair Display', serif" }}>Event Venues</h3>
            {additionalLocations.map((loc, index) => (
              <div 
                key={index} 
                onClick={() => handleLocationSelect(loc)}
                className={`p-4 rounded-lg cursor-pointer transition-all duration-300 ease-in-out shadow-md hover:shadow-xl ${activeLocationName === loc.name ? 'bg-pink-100 border-pink-500 border-2' : 'bg-white hover:bg-pink-50'}`}
              >
                <h4 className="text-xl font-bold text-pink-500">{loc.name}</h4>
                <p className="text-gray-600">{loc.address}</p>
                <a
                  href={`https://www.google.com/maps/dir/?api=1&destination=${loc.coordinates[0]},${loc.coordinates[1]}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center text-sm text-pink-600 hover:text-pink-800 mt-2 font-semibold"
                >
                  <NavigationIcon size={16} className="mr-1" /> Get Directions
                </a>
              </div>
            ))}
          </motion.div>

          <motion.div 
            className="md:col-span-2 min-h-[450px]"
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            viewport={{ once: true }}
          >
            
              <MapContainer 
                center={currentCenter} 
                zoom={currentZoom} 
                scrollWheelZoom={false} 
                className="leaflet-container"
                whenCreated={(mapInstance) => { mapRef.current = mapInstance; }}
              >
                <ChangeView center={currentCenter} zoom={currentZoom} />
                <TileLayer
                  attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &mdash; Wedding theme by Hostinger Horizons'
                  url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                />
                {additionalLocations.map((loc, index) => (
                  <Marker key={index} position={loc.coordinates} icon={DefaultIcon}>
                    <Popup>
                      <strong className="text-pink-600">{loc.name}</strong><br />{loc.address}
                      <br/>
                       <a
                        href={`https://www.google.com/maps/dir/?api=1&destination=${loc.coordinates[0]},${loc.coordinates[1]}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center text-sm text-pink-600 hover:text-pink-800 mt-1 font-semibold"
                      >
                        <NavigationIcon size={14} className="mr-1" /> Get Directions
                      </a>
                    </Popup>
                  </Marker>
                ))}
              </MapContainer>
            
          </motion.div>
        </div>
      </div>
    </section>
  );
};