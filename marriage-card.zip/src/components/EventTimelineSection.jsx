import React from 'react';
import { motion } from 'framer-motion';

export const EventTimelineSection = ({ data, CalendarIcon, MapPinIcon }) => {
  const { title, subtitle, events } = data;

  const handleLocationClick = (coordinates, locationName) => {
    const section = document.getElementById('location');
    if (section) {
      section.scrollIntoView({ behavior: 'smooth' });
    }
    
    const event = new CustomEvent('mapFocus', { detail: { coordinates, name: locationName } });
    window.dispatchEvent(event);
  };

  return (
    <section id="events" className="py-24 bg-[#FFF9FB]">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl md:text-6xl font-bold mb-4 gradient-text">{title}</h2>
          <p className="text-xl text-gray-500">{subtitle}</p>
        </motion.div>

        <div className="relative">
          <div className="absolute left-1/2 w-0.5 h-full bg-pink-200 -translate-x-1/2 hidden md:block"></div>
          {events.map((event, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.2 }}
              viewport={{ once: true }}
              className="mb-12 flex items-center w-full"
            >
              <div className={`flex flex-col md:flex-row ${index % 2 === 0 ? 'md:flex-row-reverse' : ''} w-full items-stretch`}>
                <div className="w-full md:w-5/12">
                  <div className={`p-6 rounded-lg shadow-xl bg-white md:text-right ${index % 2 !== 0 ? 'md:text-left' : 'text-left'} h-full flex flex-col justify-between`}>
                    <div>
                      <h3 className="text-2xl font-bold text-pink-500 mb-2">{event.title}</h3>
                      <div className="flex items-center mb-2 md:justify-end">
                        <p className="text-gray-600 mr-2">{event.time}</p>
                        <CalendarIcon className="h-5 w-5 text-pink-400" />
                      </div>
                      <div className="flex items-center mb-2 md:justify-end">
                        <p className="text-gray-600 mr-2">{event.locationName}</p>
                         <button 
                          onClick={() => handleLocationClick(event.coordinates, event.locationName)} 
                          className="text-pink-400 hover:text-pink-600 transition-colors"
                          aria-label={`View ${event.locationName} on map`}
                        >
                          <MapPinIcon className="h-5 w-5" />
                        </button>
                      </div>
                      <p className="text-gray-500">{event.description}</p>
                    </div>
                    <button 
                      onClick={() => handleLocationClick(event.coordinates, event.locationName)} 
                      className="mt-4 text-sm text-pink-600 hover:underline self-start md:self-end"
                    >
                      View on Map
                    </button>
                  </div>
                </div>
                <div className="w-full md:w-2/12 flex justify-center items-center my-4 md:my-0">
                  <div className="w-10 h-10 bg-pink-500 rounded-full z-10 flex items-center justify-center shadow-md">
                    <event.icon className="h-6 w-6 text-white" />
                  </div>
                </div>
                <div className="w-full md:w-5/12 hidden md:block"></div> {/* Spacer for timeline layout */}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};