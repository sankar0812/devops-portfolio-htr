import React from 'react';
import { Heart } from 'lucide-react';
import { motion } from 'framer-motion';

export const Footer = ({ couple }) => {
  return (
    <footer className="py-12 bg-white border-t border-pink-100">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-gray-600">
        <motion.div
          initial={{ opacity: 0, y:20 }}
          whileInView={{ opacity: 1, y:0 }}
          transition={{ duration:0.8 }}
          viewport={{ once: true }}
        >
          <h3 
            className="text-4xl md:text-5xl font-bold mb-4 text-pink-500"
            style={{ fontFamily: "'Great Vibes', cursive" }}
          >
            {couple.bride} & {couple.groom}
          </h3>
          <p className="text-lg mb-3" style={{ fontFamily: "'Garamond', serif" }}>
            We can't wait to celebrate our special day with you!
          </p>
          <div className="flex justify-center items-center my-5">
            <Heart className="w-8 h-8 text-pink-400 animate-pulse" />
          </div>
          <p className="text-sm text-gray-500" style={{ fontFamily: "'Montserrat', sans-serif" }}>
            &copy; {new Date().getFullYear()} {couple.bride} & {couple.groom}. All Rights Reserved.
            <br />
            Lovingly crafted with Hostinger Horizons.
          </p>
        </motion.div>
      </div>
    </footer>
  );
};