
import React from 'react';
import { motion } from 'framer-motion';

export const EventTimelineSection = ({ data, CalendarIcon, MapPinIcon }) => {
  const { title, subtitle, events } = data;
  return (
    <section id="events" className="py-24 bg-[#FFF9FB]">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl md:text-6xl font-bold mb-4 gradient-text">{title}</h2>
          <p className="text-xl text-gray-500">{subtitle}</p>
        </motion.div>

        <div className="relative">
          <div className="absolute left-1/2 w-0.5 h-full bg-pink-200 -translate-x-1/2"></div>
          {events.map((event, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.2 }}
              viewport={{ once: true }}
              className="mb-12 flex items-center w-full"
            >
              <div className={`flex ${index % 2 === 0 ? 'flex-row-reverse' : ''} w-full`}>
                <div className="w-5/12">
                  <div className={`p-6 rounded-lg shadow-lg bg-white text-right ${index % 2 !== 0 ? 'text-left' : ''}`}>
                    <h3 className="text-2xl font-bold text-pink-500 mb-2">{event.title}</h3>
                    <div className="flex items-center mb-2 justify-end">
                      <p className="text-gray-600 mr-2">{event.time}</p>
                      <CalendarIcon className="h-5 w-5 text-pink-400" />
                    </div>
                    <div className="flex items-center mb-2 justify-end">
                      <p className="text-gray-600 mr-2">{event.location}</p>
                      <MapPinIcon className="h-5 w-5 text-pink-400" />
                    </div>
                    <p className="text-gray-500">{event.description}</p>
                  </div>
                </div>
                <div className="w-2/12 flex justify-center">
                  <div className="w-8 h-8 bg-pink-500 rounded-full z-10 flex items-center justify-center shadow-md">
                    <event.icon className="h-5 w-5 text-white" />
                  </div>
                </div>
                <div className="w-5/12"></div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
