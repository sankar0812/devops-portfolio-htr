
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';

export const RsvpSection = ({ onSubmit, SendIcon }) => {
  const [name, setName] = useState('');
  const [attendance, setAttendance] = useState('attending');
  const [guests, setGuests] = useState(1);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({ name, attendance, guests });
    setName('');
    setAttendance('attending');
    setGuests(1);
  };

  return (
    <section id="rsvp" className="py-24 bg-[#FFF9FB]">
      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-5xl md:text-6xl font-bold mb-4 gradient-text">RSVP</h2>
          <p className="text-xl text-gray-500">We would be honored to have you with us.</p>
        </motion.div>

        <motion.form
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          viewport={{ once: true }}
          onSubmit={handleSubmit}
          className="bg-white p-8 rounded-xl shadow-lg space-y-6"
        >
          <div className="space-y-2">
            <Label htmlFor="name" className="text-lg">Your Full Name</Label>
            <Input id="name" type="text" placeholder="John Doe" value={name} onChange={(e) => setName(e.target.value)} required />
          </div>

          <div className="space-y-3">
            <Label className="text-lg">Will you be attending?</Label>
            <RadioGroup defaultValue="attending" value={attendance} onValueChange={setAttendance}>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="attending" id="r1" />
                <Label htmlFor="r1">Joyfully Attending</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="not-attending" id="r2" />
                <Label htmlFor="r2">Regretfully Decline</Label>
              </div>
            </RadioGroup>
          </div>

          {attendance === 'attending' && (
            <div className="space-y-2">
              <Label htmlFor="guests" className="text-lg">Number of Guests</Label>
              <Input id="guests" type="number" min="1" max="5" value={guests} onChange={(e) => setGuests(parseInt(e.target.value))} required />
            </div>
          )}

          <Button type="submit" size="lg" className="w-full gradient-bg text-white hover:scale-105 transition-transform duration-300">
            <SendIcon className="mr-2 h-5 w-5" />
            Send RSVP
          </Button>
        </motion.form>
      </div>
    </section>
  );
};
