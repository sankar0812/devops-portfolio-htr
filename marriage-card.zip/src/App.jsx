
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Toaster } from '@/components/ui/toaster';
import { toast } from '@/components/ui/use-toast';
import { Navbar } from '@/components/Navbar';
import { HeroSection } from '@/components/HeroSection';
import { OurStorySection } from '@/components/OurStorySection';
import { EventTimelineSection } from '@/components/EventTimelineSection';
import { GallerySection } from '@/components/GallerySection';
import { LocationSection } from '@/components/LocationSection';
import { Footer } from '@/components/Footer';
import { 
  Heart, 
  Calendar, 
  MapPin, 
  Gift, 
  Menu, 
  X,
  Navigation,
  MoonStar, 
  Palette 
} from 'lucide-react';

const App = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    document.documentElement.classList.add('scroll-smooth');
    document.body.style.backgroundColor = '#FFF8F0'; 
  }, []);

  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMenuOpen(false);
  };

  const handleRegistryClick = () => {
    toast({
      title: "🎁 Shagun & Blessings",
      description: "Your presence is our most cherished gift. If you wish to offer a token of love, details will be shared soon.",
      className: "bg-orange-50 border-orange-300 text-orange-700",
    });
  };

  const navItems = ['Home', 'Our Story', 'Events', 'Gallery', 'Location'];

  const couple = {
    groom: "Rohan Sharma",
    bride: "Priya Patel",
    date: "November 16, 2025",
  };

  const storyData = {
    title: "Our Sacred Journey",
    subtitle: "Two souls, one divine path.",
    story: "From auspicious beginnings to a promise of eternity, our love story is woven with threads of tradition and destiny. We found each other under the guiding stars, and every moment since has been a celebration of shared values and deep affection. We are immensely joyful to embark on our Grihastha Ashrama, and to share the sanctity and splendor of our union with you.",
    groomImageAlt: "Rohan Sharma, the groom, in traditional attire",
    brideImageAlt: "Priya Patel, the bride, in beautiful wedding wear",
  };

  const eventsData = {
    title: "Wedding Ceremonies",
    subtitle: "Join us as we celebrate our sacred union.",
    events: [
      {
        icon: Palette, 
        title: "Mehndi & Sangeet",
        time: "November 15, 2025 - 5:00 PM",
        locationName: "Patel Residence Gardens",
        address: "123 Garden Lane, Mumbai, India",
        coordinates: [19.0760, 72.8777], 
        description: "An evening of vibrant henna, joyful music, and traditional dances.",
      },
      {
        icon: MoonStar, 
        title: "Vivah Sanskar (Wedding Ceremony)",
        time: "November 16, 2025 - 10:00 AM",
        locationName: "Shri Krishna Temple",
        address: "Temple Road, Mumbai, India",
        coordinates: [19.0780, 72.8790], 
        description: "Witness our sacred vows as per Vedic traditions in the divine presence.",
      },
      {
        icon: Gift,
        title: "Ashirwad & Reception (Grand Feast)",
        time: "November 16, 2025 - 7:00 PM",
        locationName: "Rajwada Mahal Banquet",
        address: "Royal Palace Road, Mumbai, India",
        coordinates: [19.0800, 72.8810], 
        description: "Join us for blessings, a grand feast, and joyful celebrations at the Mahal.",
      },
    ],
  };
  
  const locationData = {
    title: "Ceremony & Celebration Venues",
    subtitle: "Find your way to our joyous occasions.",
    mainLocation: { 
      name: "Shri Krishna Temple",
      address: "Temple Road, Mumbai, India",
      coordinates: [19.0780, 72.8790],
      zoom: 14,
    },
    additionalLocations: eventsData.events.map(event => ({
      name: event.locationName,
      coordinates: event.coordinates,
      address: event.address,
    }))
  };

  const galleryData = {
    title: "Our Auspicious Moments",
    subtitle: "A kaleidoscope of our traditions, love, and joyous celebrations.",
    images: [
      { id: 1, description: "Couple in traditional Indian wedding attire during a ceremony", altText: "Sacred vows, eternal bond" },
      { id: 2, description: "Bride's hands adorned with intricate Mehndi designs", altText: "Artistry of love and tradition" },
      { id: 3, description: "Couple performing a traditional Hindu wedding ritual", altText: "Rituals that bind our souls" },
      { id: 4, description: "Colorful decorations at an Indian wedding venue", altText: "Vibrancy of our celebrations" },
      { id: 5, description: "Family and friends celebrating during a Sangeet ceremony", altText: "Joyful dances, united hearts" },
      { id: 6, description: "Groom arriving on a decorated horse (Baraat)", altText: "The grand arrival" },
      { id: 7, description: "Couple sharing a sweet moment during the reception", altText: "A new chapter begins" },
      { id: 8, description: "Traditional Indian sweets and delicacies served at wedding", altText: "Sweet beginnings, shared joys" },
      { id: 9, description: "Bride getting ready with makeup and jewelry for wedding", altText: "Bridal elegance" },
      { id: 10, description: "Mandap decoration with flowers for Hindu wedding ceremony", altText: "Sacred space" },
      { id: 11, description: "Guests enjoying traditional Indian feast at wedding reception", altText: "Feast of joy" },
      { id: 12, description: "Close up of couple's hands during ring exchange ceremony", altText: "Symbol of unity" },
    ],
  };

  return (
    <div className="min-h-screen bg-[#FFF8F0] text-gray-800 overflow-x-hidden">
      <Toaster />
      <Navbar 
        navItems={navItems} 
        isMenuOpen={isMenuOpen} 
        setIsMenuOpen={setIsMenuOpen} 
        scrollToSection={scrollToSection}
        MenuIcon={Menu}
        XIcon={X}
        couple={couple}
      />
      <HeroSection couple={couple} scrollToSection={scrollToSection} HeartIcon={Heart} GiftIcon={Gift} onRegistryClick={handleRegistryClick} />
      <OurStorySection data={storyData} />
      <EventTimelineSection data={eventsData} CalendarIcon={Calendar} MapPinIcon={MapPin} />
      <GallerySection data={galleryData} />
      <LocationSection data={locationData} NavigationIcon={Navigation} />
      <Footer couple={couple} />
    </div>
  );
};

export default App;
